-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: watchandplay
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES UTF8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `doctrine_migration_versions`
--

DROP TABLE IF EXISTS `doctrine_migration_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctrine_migration_versions` (
  `version` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctrine_migration_versions`
--

LOCK TABLES `doctrine_migration_versions` WRITE;
/*!40000 ALTER TABLE `doctrine_migration_versions` DISABLE KEYS */;
INSERT INTO `doctrine_migration_versions` VALUES ('DoctrineMigrations\\Version20221107135104','2022-11-13 14:45:58',918),('DoctrineMigrations\\Version20221113144625','2022-11-13 14:46:38',312);
/*!40000 ALTER TABLE `doctrine_migration_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game`
--

DROP TABLE IF EXISTS `game`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `game` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trailer_id` int(11) NOT NULL,
  `name` varchar(155) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_release` date NOT NULL,
  `editor` varchar(155) COLLATE utf8mb4_unicode_ci NOT NULL,
  `developer` varchar(155) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `path_img` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_232B318CB6C04CFD` (`trailer_id`),
  CONSTRAINT `FK_232B318CB6C04CFD` FOREIGN KEY (`trailer_id`) REFERENCES `trailer` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game`
--

LOCK TABLES `game` WRITE;
/*!40000 ALTER TABLE `game` DISABLE KEYS */;
INSERT INTO `game` VALUES (1,1,'Final Fantasy 7 Remake','2022-06-17','Square Enix','Square Enix','Final Fantasy VII Remake est le remake de Final Fantasy VII. Le joueur y incarne toujours Cloud  un ancien soldat ayant rejoint le groupe terroriste Avalanche. Ce dernier essaye de déjouer les plans de la Shinra et en vient à se battre avec Sephiroth.','ff7remakecover.jpeg'),(2,2,'Final Fantasy 15','2018-03-06','Square Enix','Square Enix','Anciennement nommé Final Fantasy XIII Versus, Final Fantasy XV est un J-RPG de la célèbre série Final Fantasy. Le joueur y incarne Noctis, héritier du roi, accompagné de ses amis, dans un monde moderne, sombre, et fantastique.','ff15cover.jpg'),(3,3,'The Binding of Isaac','2011-09-28','Edmund McMillen ','Edmund McMillen ','The Binding of Isaac est un jeu d\'action/aventure sur PC. Vous y incarnez le petit Isaac qui va devoir traverser une tripotée de donjons générés aléatoirement afin d\'aller tuer sa génitrice. Bien qu\'influencé par Zelda, le titre se veut glauque et trash tout en proposant de multiples boss à combattre et des tas d\'objets à récupérer.','tboicover.jpeg'),(4,4,'Skyrim','2011-11-11','Bethesda Softworks ','Bethesda Softworks ','The Elder Scrolls V : Skyrim est le cinquième épisode de la saga de jeux de rôle du même nom. Le scénario se passe 200 ans après l\'histoire du quatrième opus quand Alduin fait son retour au milieu d\'une guerre civile. Seul le Dovahkiin','skyrimcover.jpeg'),(5,5,'The Witcher 3','2015-05-18','CD Projekt RED','CD Projekt','The Witcher 3 : Wild Hunt est un Action-RPG se déroulant dans un monde ouvert. Troisième épisode de la série du même nom inspirée des livres du polonais Andrzej Sapkowski','thewitcher3cover.jpeg'),(6,6,'Xenoblade Chronicles','2010-06-10','Monster Games','Nintendo','Xenoblade Chronicles Definitive Edition sur Nintendo Switch est une nouvelle édition du jeu paru sur Wii en 2011. Elle propose un nouvel épilogue appelé \"Un avenir commun\" des musiques remastérisées','xenobladechroniclescover.jpg'),(7,7,'Elden Ring','2022-02-25','From Software','Bandai Namco','Elden Ring est le nouveau jeu de From Software. Il s\'agit d\'un Action-RPG à la troisième personne qui se déroule dans un monde ouvert. Le jeu marque la collaboration entre Hidetaka Miyazaki et George R. R. Martin, le créateur de Game of Thrones.','eldenringcover.jpg'),(8,8,'Persona 5','2016-09-15','Atlus','Atlus','Disponible sur PS4 Persona 5 se déroule à Tokyo','persona5cover.jpeg'),(9,9,'Yakuza 6','2016-12-08','Ryū ga Gotoku Studio','Sega','Yakuza 6 sur PS4 est un jeu de type aventure en monde ouvert. Après les événements du 5e volet, on retrouve Kazuma, qui après avoir apprit qu\'Haruka eu été gravement blessé, va tenter de l\'aider et de trouver des réponses sur son agression. Pour cela, il va se rendre à Hiroshima, dernier endroit dans lequel s\'est rendu la jeune fille. En plus de cela, des problèmes au sein du clan Tojo refont surface...','yakuza6cover.jpeg');
/*!40000 ALTER TABLE `game` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_platform`
--

DROP TABLE IF EXISTS `game_platform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `game_platform` (
  `game_id` int(11) NOT NULL,
  `platform_id` int(11) NOT NULL,
  PRIMARY KEY (`game_id`,`platform_id`),
  KEY `IDX_92162FEDE48FD905` (`game_id`),
  KEY `IDX_92162FEDFFE6496F` (`platform_id`),
  CONSTRAINT `FK_92162FEDE48FD905` FOREIGN KEY (`game_id`) REFERENCES `game` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_92162FEDFFE6496F` FOREIGN KEY (`platform_id`) REFERENCES `platform` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_platform`
--

LOCK TABLES `game_platform` WRITE;
/*!40000 ALTER TABLE `game_platform` DISABLE KEYS */;
INSERT INTO `game_platform` VALUES (1,2),(2,2),(3,4),(4,1),(4,2),(4,3),(4,4),(5,1),(5,2),(5,3),(5,4),(6,1),(7,2),(7,3),(7,4),(8,2),(9,2);
/*!40000 ALTER TABLE `game_platform` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_type`
--

DROP TABLE IF EXISTS `game_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `game_type` (
  `game_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  PRIMARY KEY (`game_id`,`type_id`),
  KEY `IDX_67CB3B05E48FD905` (`game_id`),
  KEY `IDX_67CB3B05C54C8C93` (`type_id`),
  CONSTRAINT `FK_67CB3B05C54C8C93` FOREIGN KEY (`type_id`) REFERENCES `type` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_67CB3B05E48FD905` FOREIGN KEY (`game_id`) REFERENCES `game` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_type`
--

LOCK TABLES `game_type` WRITE;
/*!40000 ALTER TABLE `game_type` DISABLE KEYS */;
INSERT INTO `game_type` VALUES (1,1),(1,2),(1,3),(2,1),(2,2),(2,3),(3,3),(3,5),(4,1),(4,2),(4,3),(5,1),(5,2),(5,3),(6,1),(6,2),(6,3),(7,1),(7,2),(7,3),(7,4),(8,1),(8,2),(8,3),(9,1),(9,2),(9,3);
/*!40000 ALTER TABLE `game_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `key`
--

DROP TABLE IF EXISTS `key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `key` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `game_id` int(11) DEFAULT NULL,
  `platform_id` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sold_out` date DEFAULT NULL,
  `price` int(11) NOT NULL,
  `price_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_8A90ABA9E48FD905` (`game_id`),
  KEY `IDX_8A90ABA9FFE6496F` (`platform_id`),
  CONSTRAINT `FK_8A90ABA9E48FD905` FOREIGN KEY (`game_id`) REFERENCES `game` (`id`),
  CONSTRAINT `FK_8A90ABA9FFE6496F` FOREIGN KEY (`platform_id`) REFERENCES `platform` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `key`
--

LOCK TABLES `key` WRITE;
/*!40000 ALTER TABLE `key` DISABLE KEYS */;
INSERT INTO `key` VALUES (1,8,2,'KEYNUMBER0','2022-11-05',3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(2,4,3,'KEYNUMBER1',NULL,2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(3,4,3,'KEYNUMBER2',NULL,2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(4,3,1,'KEYNUMBER3','2022-10-28',4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(5,4,2,'KEYNUMBER4',NULL,3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(6,2,4,'KEYNUMBER5','2022-10-20',3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(7,5,3,'KEYNUMBER6','2022-10-20',2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(8,7,2,'KEYNUMBER7','2022-10-29',2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(9,7,2,'KEYNUMBER8','2022-11-08',2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(10,6,3,'KEYNUMBER9',NULL,3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(11,2,1,'KEYNUMBER10',NULL,3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(12,7,4,'KEYNUMBER11',NULL,2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(13,7,2,'KEYNUMBER12',NULL,2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(14,9,4,'KEYNUMBER13',NULL,3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(15,6,3,'KEYNUMBER14',NULL,4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(16,8,3,'KEYNUMBER15','2022-11-09',2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(17,7,3,'KEYNUMBER16',NULL,4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(18,7,4,'KEYNUMBER17',NULL,2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(19,4,1,'KEYNUMBER18','2022-11-10',4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(20,6,3,'KEYNUMBER19','2022-11-10',2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(21,9,2,'KEYNUMBER20',NULL,4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(22,9,3,'KEYNUMBER21','2022-10-26',4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(23,8,3,'KEYNUMBER22','2022-10-22',3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(24,6,1,'KEYNUMBER23','2022-11-07',2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(25,2,4,'KEYNUMBER24','2022-10-30',2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(26,3,3,'KEYNUMBER25','2022-10-31',3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(27,3,4,'KEYNUMBER26',NULL,3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(28,8,3,'KEYNUMBER27','2022-10-30',3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(29,9,3,'KEYNUMBER28','2022-11-05',4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(30,5,3,'KEYNUMBER29',NULL,4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(31,5,2,'KEYNUMBER30',NULL,3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(32,9,3,'KEYNUMBER31',NULL,3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(33,6,4,'KEYNUMBER32',NULL,3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(34,7,4,'KEYNUMBER33',NULL,3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(35,8,3,'KEYNUMBER34',NULL,3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(36,9,4,'KEYNUMBER35',NULL,3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(37,3,3,'KEYNUMBER36','2022-11-02',3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(38,7,1,'KEYNUMBER37','2022-11-07',3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(39,2,2,'KEYNUMBER38','2022-10-16',2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(40,5,4,'KEYNUMBER39','2022-11-08',3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(41,8,1,'KEYNUMBER40','2022-11-10',3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(42,9,2,'KEYNUMBER41','2022-10-16',3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(43,3,4,'KEYNUMBER42',NULL,3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(44,8,1,'KEYNUMBER43',NULL,2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(45,7,2,'KEYNUMBER44','2022-10-16',2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(46,3,3,'KEYNUMBER45',NULL,4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(47,3,4,'KEYNUMBER46','2022-10-29',4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(48,3,4,'KEYNUMBER47',NULL,2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(49,4,1,'KEYNUMBER48',NULL,4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(50,7,1,'KEYNUMBER49',NULL,2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(51,8,1,'KEYNUMBER50','2022-10-24',3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(52,7,3,'KEYNUMBER51','2022-10-28',3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(53,4,2,'KEYNUMBER52',NULL,3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(54,3,1,'KEYNUMBER53','2022-11-03',2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(55,2,2,'KEYNUMBER54','2022-11-02',3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(56,7,3,'KEYNUMBER55','2022-11-07',4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(57,5,3,'KEYNUMBER56',NULL,2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(58,2,1,'KEYNUMBER57',NULL,2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(59,8,3,'KEYNUMBER58',NULL,4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(60,8,3,'KEYNUMBER59',NULL,2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(61,9,2,'KEYNUMBER60',NULL,4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(62,6,2,'KEYNUMBER61',NULL,3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(63,6,4,'KEYNUMBER62','2022-10-19',3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(64,6,3,'KEYNUMBER63','2022-11-13',3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(65,5,2,'KEYNUMBER64',NULL,3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(66,3,1,'KEYNUMBER65',NULL,3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(67,4,2,'KEYNUMBER66',NULL,4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(68,8,2,'KEYNUMBER67',NULL,2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(69,8,1,'KEYNUMBER68','2022-11-08',4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(70,8,2,'KEYNUMBER69',NULL,2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(71,4,4,'KEYNUMBER70','2022-10-30',4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(72,7,2,'KEYNUMBER71','2022-10-28',4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(73,2,2,'KEYNUMBER72','2022-11-07',2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(74,9,3,'KEYNUMBER73',NULL,4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(75,8,4,'KEYNUMBER74',NULL,3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(76,7,1,'KEYNUMBER75','2022-11-08',2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(77,2,1,'KEYNUMBER76',NULL,4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(78,8,1,'KEYNUMBER77',NULL,4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(79,5,3,'KEYNUMBER78',NULL,2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(80,2,4,'KEYNUMBER79',NULL,3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(81,3,3,'KEYNUMBER80',NULL,2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(82,2,4,'KEYNUMBER81',NULL,4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(83,2,3,'KEYNUMBER82',NULL,4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(84,7,2,'KEYNUMBER83','2022-10-27',3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(85,6,4,'KEYNUMBER84','2022-11-07',3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(86,9,4,'KEYNUMBER85','2022-11-08',3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(87,9,1,'KEYNUMBER86','2022-11-01',2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(88,2,1,'KEYNUMBER87',NULL,3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(89,9,2,'KEYNUMBER88','2022-11-08',4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(90,9,1,'KEYNUMBER89',NULL,4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(91,4,1,'KEYNUMBER90','2022-11-10',4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(92,6,1,'KEYNUMBER91','2022-10-21',2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(93,3,4,'KEYNUMBER92','2022-11-10',4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(94,8,3,'KEYNUMBER93',NULL,4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(95,9,3,'KEYNUMBER94',NULL,4000,'price_1M3hOdAzFZHUM3llXdsmghBk'),(96,3,1,'KEYNUMBER95',NULL,2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(97,5,3,'KEYNUMBER96',NULL,3000,'price_1M3hOdAzFZHUM3llLxSNQVGI'),(98,7,2,'KEYNUMBER97',NULL,2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(99,4,4,'KEYNUMBER98','2022-10-18',2000,'price_1M3hOdAzFZHUM3llGEHykOmW'),(100,2,4,'KEYNUMBER99',NULL,2000,'price_1M3hOdAzFZHUM3llGEHykOmW');
/*!40000 ALTER TABLE `key` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lign_order`
--

DROP TABLE IF EXISTS `lign_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lign_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ordertable_id` int(11) NOT NULL,
  `keytable_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_17E5FBCAFA61ED1F` (`keytable_id`),
  KEY `IDX_17E5FBCA6ECD606A` (`ordertable_id`),
  CONSTRAINT `FK_17E5FBCA6ECD606A` FOREIGN KEY (`ordertable_id`) REFERENCES `order` (`id`),
  CONSTRAINT `FK_17E5FBCAFA61ED1F` FOREIGN KEY (`keytable_id`) REFERENCES `key` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lign_order`
--

LOCK TABLES `lign_order` WRITE;
/*!40000 ALTER TABLE `lign_order` DISABLE KEYS */;
INSERT INTO `lign_order` VALUES (1,1,1),(2,1,2),(3,1,3),(4,2,4),(5,2,5),(6,2,6),(7,2,7),(8,3,8),(9,4,9),(10,4,10),(11,5,11),(12,5,12),(13,5,13),(14,5,14),(15,6,15),(16,7,16),(17,7,17),(18,8,18),(19,8,19),(20,8,20),(21,9,21),(22,9,22),(23,10,23),(24,10,24),(25,10,25),(26,10,26),(27,11,27),(28,11,28),(29,11,29),(30,11,30),(31,12,31),(32,12,32),(33,12,33),(34,13,34),(35,13,35),(36,13,36),(37,13,37),(38,14,38),(39,15,39),(40,15,40),(41,16,41),(42,16,42),(43,17,43),(44,17,44),(45,17,45),(46,18,46),(47,19,47),(48,19,48),(49,19,49),(50,20,50),(51,20,51),(52,20,52),(53,20,53),(54,21,54),(55,21,55),(56,21,56),(57,21,57),(58,22,58),(59,22,59),(60,22,60),(61,22,61),(62,23,62),(63,23,63),(64,24,64),(65,25,65),(66,25,66),(67,25,67),(68,25,68);
/*!40000 ALTER TABLE `lign_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messenger_messages`
--

DROP TABLE IF EXISTS `messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messenger_messages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `body` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `headers` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue_name` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_75EA56E0FB7336F0` (`queue_name`),
  KEY `IDX_75EA56E0E3BD61CE` (`available_at`),
  KEY `IDX_75EA56E016BA31DB` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messenger_messages`
--

LOCK TABLES `messenger_messages` WRITE;
/*!40000 ALTER TABLE `messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `company_name` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_F5299398A76ED395` (`user_id`),
  CONSTRAINT `FK_F5299398A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` VALUES (1,4,'WatchAndPlay','Jerde','Sigrid','bstark@hotmail.com'),(2,3,'WatchAndPlay','Wyman','Quinn','greyson.walker@towne.com'),(3,2,'WatchAndPlay','Hauck','Shad','dmcclure@bruen.com'),(4,9,'WatchAndPlay','Ruecker','Arlie','tillman.gudrun@simonis.net'),(5,6,'WatchAndPlay','Zieme','Dorcas','murray.stefanie@heaney.com'),(6,4,'WatchAndPlay','Hills','Cloyd','rosa.cronin@gmail.com'),(7,9,'WatchAndPlay','Hills','Adolph','jakubowski.coty@hotmail.com'),(8,4,'WatchAndPlay','Eichmann','Moshe','zlarson@hotmail.com'),(9,8,'WatchAndPlay','Frami','Zane','kilback.julian@wolff.com'),(10,9,'WatchAndPlay','Morissette','Cathryn','jeromy.schmitt@hotmail.com'),(11,4,'WatchAndPlay','Douglas','Brook','alexie70@block.com'),(12,7,'WatchAndPlay','Effertz','Birdie','lpollich@yahoo.com'),(13,3,'WatchAndPlay','Moore','Annamarie','mills.russel@gmail.com'),(14,7,'WatchAndPlay','Quitzon','Florence','schiller.dayna@reynolds.biz'),(15,5,'WatchAndPlay','Grady','Reece','dare.kellie@schmeler.org'),(16,7,'WatchAndPlay','Metz','Edgar','whitney.jacobson@okeefe.info'),(17,5,'WatchAndPlay','Klocko','Meggie','heathcote.valentin@yahoo.com'),(18,8,'WatchAndPlay','Greenfelder','Gunner','ehowe@gmail.com'),(19,4,'WatchAndPlay','Senger','Mac','amber.kuvalis@yahoo.com'),(20,5,'WatchAndPlay','Collins','Verlie','langworth.sigrid@daniel.com'),(21,5,'WatchAndPlay','Reynolds','Vicenta','julianne.champlin@wilderman.org'),(22,5,'WatchAndPlay','Breitenberg','Ebba','gutkowski.savanah@gmail.com'),(23,8,'WatchAndPlay','Carter','Elinore','pkoepp@graham.com'),(24,5,'WatchAndPlay','Crooks','Amalia','gskiles@hotmail.com'),(25,6,'WatchAndPlay','Romaguera','Oran','vbins@blanda.info');
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `platform`
--

DROP TABLE IF EXISTS `platform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `platform` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `platform`
--

LOCK TABLES `platform` WRITE;
/*!40000 ALTER TABLE `platform` DISABLE KEYS */;
INSERT INTO `platform` VALUES (1,'Switch'),(2,'PlayStation 4'),(3,'XboX One'),(4,'PC');
/*!40000 ALTER TABLE `platform` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trailer`
--

DROP TABLE IF EXISTS `trailer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trailer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path_video` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trailer`
--

LOCK TABLES `trailer` WRITE;
/*!40000 ALTER TABLE `trailer` DISABLE KEYS */;
INSERT INTO `trailer` VALUES (1,'ff7remaketrailer.mp4'),(2,'ff15trailer.mp4'),(3,'tboitrailer.mp4'),(4,'skyrimtrailer.mp4'),(5,'thewitcher3trailer.mp4'),(6,'xenobladetrailer.mp4'),(7,'eldenringtrailer.mp4'),(8,'persona5trailer.mp4'),(9,'yakuza6trailer.mp4');
/*!40000 ALTER TABLE `trailer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `type`
--

DROP TABLE IF EXISTS `type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type`
--

LOCK TABLES `type` WRITE;
/*!40000 ALTER TABLE `type` DISABLE KEYS */;
INSERT INTO `type` VALUES (1,'RPG'),(2,'Action'),(3,'Aventure'),(4,'Dark-Fantasy'),(5,'Rogue-like');
/*!40000 ALTER TABLE `type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nickname` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(155) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id_stripe` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin@admin.com','$2y$12$OePDxlGEch94ST.gNIgCuuvGgUlFWn7Fj8dgCpL2XLI1jicxXVYnK','ward55','Maximilian','Gleichner','fafjz','admin',1),(2,'toto@toto.com','$2y$12$Toqu5Nfi3ZQ0n52VY2J1ZeK2tzkI1X6JkYF.x4ckrsJRUe6SFo.US','kwill','Gus','Schamberger','fafjz','user',1),(3,'monserrate94@yahoo.com','$2y$12$15YhN2ZaRa0gXsrdsRR7leV/1NZ9GjuEfKRSscjZus0TKwAQ8pZmO','bosco.dimitri','Keyon','Schuppe','fafjz','user',1),(4,'pmurphy@yahoo.com','$2y$12$zROS/WjCZC2jmCSBLE6YY.dRbbEEfFQqviABmEVLGIfGI3XX8WZ3a','qhagenes','Gregorio','Welch','fafjz','user',1),(5,'ycollins@yahoo.com','$2y$12$gC.agaqxq9WBqb3LT7Yjje6dV6QY2gYi4gJ4YP4xtl/T73g2YVkjK','mcdermott.ruby','Samanta','Orn','fafjz','user',1),(6,'arne18@gmail.com','$2y$12$wTKYJEgzTUnD0XTIL7O1EOTGflDX/PrSDD/QOMNgq8V8bYgdUxZlG','hudson.sporer','Russell','Kub','fafjz','user',1),(7,'heller.gilberto@yahoo.com','$2y$12$PReT0JSzYFNeMm/4scZt/u10qPmrCn1Vjj0jAj80U0cOCMNnETC46','cecile01','Willy','Ernser','fafjz','user',0),(8,'nrodriguez@hamill.com','$2y$12$aJK/pBTRkjnSepEdWAkXm.LKe4an3uOHwIoQh89ElAQ8nerSIkDXa','vandervort.lisa','Zackery','Wolf','fafjz','user',1),(9,'morton.daugherty@gmail.com','$2y$12$cBWLlzO8BETz7lBDC7tB4uCxrwULi8RkGQYw51.VxpGq0A2x.0KxK','camilla22','Dominique','Lind','fafjz','user',0),(10,'pritchie@gmail.com','$2y$12$FwcXMVaf0J4TFzriQX7sgOHr/lunP9AqZu1gXxx4bx3NhocH/XS26','jferry','Josefa','Renner','fafjz','user',1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_youtube`
--

DROP TABLE IF EXISTS `video_youtube`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_youtube` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `game_id` int(11) NOT NULL,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `youtuber` varchar(155) COLLATE utf8mb4_unicode_ci NOT NULL,
  `episode` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_15957099E48FD905` (`game_id`),
  CONSTRAINT `FK_15957099E48FD905` FOREIGN KEY (`game_id`) REFERENCES `game` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_youtube`
--

LOCK TABLES `video_youtube` WRITE;
/*!40000 ALTER TABLE `video_youtube` DISABLE KEYS */;
INSERT INTO `video_youtube` VALUES (1,1,'I0h69c5ihE0','At0miumVOD','Episode1'),(2,1,'4lz7dlcmuFo','At0miumVOD','Episode2'),(3,1,'pUQEMT4A7is','At0miumVOD','Episode3'),(4,1,'tODK1gYo1gM','At0miumVOD','Episode4'),(5,1,'f9Pteibou6w','At0miumVOD','Episode5'),(6,1,'_ltoVMWO6WY','At0miumVOD','Episode6'),(7,1,'flsknKrer7w','At0miumVOD','Episode7'),(8,1,'39Zlyuvo7is','At0miumVOD','Episode8'),(9,1,'CW1hVjUOdjo','At0miumVOD','Episode9'),(10,1,'DgmBHBr1xTo','At0miumVOD','Episode10'),(11,1,'TjdKOKsNs90','At0miumVOD','Episode11'),(12,1,'mGKTGzvhbrI','At0miumVOD','Episode12'),(13,2,'WAd1UUgTV_I','At0miumVOD','Episode1'),(14,2,'sQo6OqiQ32c','At0miumVOD','Episode2'),(15,2,'w6ezlITORcY','At0miumVOD','Episode3'),(16,2,'e98SQmW6Znk','At0miumVOD','Episode4'),(17,2,'7HX6fPDv5Qo','At0miumVOD','Episode5'),(18,2,'NRS8LJUEF9g','At0miumVOD','Episode6'),(19,2,'jqp3S22NBvk','At0miumVOD','Episode7'),(20,2,'36pINX_iHLo','At0miumVOD','Episode8'),(21,2,'kReSByM5ghQ','At0miumVOD','Episode9'),(22,2,'po15mJCSJ00','At0miumVOD','Episode10'),(23,2,'PXhbJCc7Q1M','At0miumVOD','Episode11'),(24,2,'OG76P-GRvXg','At0miumVOD','Episode12'),(25,3,'efus_V-9izk','MisterMV','Episode1'),(26,3,'WvozEvamYZ0','MisterMV','Episode2'),(27,3,'tKoJWtHvVPg','MisterMV','Episode3'),(28,3,'e87HpThhfS8','MisterMV','Episode4'),(29,3,'YbEDuy-ZfXw','MisterMV','Episode5'),(30,3,'6Zc_7KBgkvA','MisterMV','Episode6'),(31,3,'LGbE_WczCHM','MisterMV','Episode7'),(32,3,'Zg0mkFeqL58','MisterMV','Episode8'),(33,3,'3lX9RSGzNp0','MisterMV','Episode9'),(34,3,'8bvjLufdrjs','MisterMV','Episode10'),(35,3,'sj9aXiX8W2c','MisterMV','Episode11'),(36,3,'zOOCRDB-fo8','MisterMV','Episode12'),(37,4,'mih2Wepd9z8','AlderiateVOD','Episode1'),(38,4,'98QIc_x4jsM','AlderiateVOD','Episode2'),(39,4,'lf2CoC-vlt8','AlderiateVOD','Episode3'),(40,4,'LtP9uEd8k94','AlderiateVOD','Episode4'),(41,4,'Yl2ojtaFFA4','AlderiateVOD','Episode5'),(42,4,'qWk2xAAw1aM','AlderiateVOD','Episode6'),(43,4,'ltt7AwbKOi8','AlderiateVOD','Episode7'),(44,4,'w4TcYZXtPio','AlderiateVOD','Episode8'),(45,4,'OXQi2aqo6E4','AlderiateVOD','Episode9'),(46,4,'X5jwglPMcxA','AlderiateVOD','Episode10'),(47,4,'XTOjQSPr7C0','AlderiateVOD','Episode11'),(48,4,'wCW2QWoaIps','AlderiateVOD','Episode12'),(49,5,'oQOW9O6yxQI','Bob Lennon','Episode1'),(50,5,'xgCNyyICIJY','Bob Lennon','Episode2'),(51,5,'7_BCXMVHwtc','Bob Lennon','Episode3'),(52,5,'KEgeZaOII24','Bob Lennon','Episode4'),(53,5,'rylxVBfar_M','Bob Lennon','Episode5'),(54,5,'W3kvmFr88O0','Bob Lennon','Episode6'),(55,5,'Zer5Ep7YJbQ','Bob Lennon','Episode7'),(56,5,'uJc2fTake8Y','Bob Lennon','Episode8'),(57,5,'x6go-o0TNd4','Bob Lennon','Episode9'),(58,5,'gTgVcK8E7tM','Bob Lennon','Episode10'),(59,5,'KHgaC_ZC7Ag','Bob Lennon','Episode11'),(60,5,'sq_aVmWhDjI','Bob Lennon','Episode12'),(61,6,'EAE34br20gw','Alliance Rainbow','Episode1'),(62,6,'GXvMId39Lv0','Alliance Rainbow','Episode2'),(63,6,'bfx9EsQt9W4','Alliance Rainbow','Episode3'),(64,6,'HngIORzVHjY','Alliance Rainbow','Episode4'),(65,6,'bnHXg06yDIc','Alliance Rainbow','Episode5'),(66,6,'iuCciPxPMYU','Alliance Rainbow','Episode6'),(67,6,'-Fpmjl8DwIk','Alliance Rainbow','Episode7'),(68,6,'RPk2NRNsBWE','Alliance Rainbow','Episode8'),(69,6,'3WxifisMFkE','Alliance Rainbow','Episode9'),(70,6,'kHirq2q0ktg','Alliance Rainbow','Episode10'),(71,6,'pOVuttP722k','Alliance Rainbow','Episode11'),(72,6,'wqmR36gKj9Y','Alliance Rainbow','Episode12'),(73,7,'NNKo6xzit_s','At0miumVOD','Episode1'),(74,7,'Cx-wZnQquSQ','At0miumVOD','Episode2'),(75,7,'0HBav8iR3-A','At0miumVOD','Episode3'),(76,7,'E_aW9iWajZ8','At0miumVOD','Episode4'),(77,7,'jTIYW9zZe5w','At0miumVOD','Episode5'),(78,7,'0ALLU3hTw34','At0miumVOD','Episode6'),(79,7,'giCD1q7BWqo','At0miumVOD','Episode7'),(80,7,'hoFRraotZbM','At0miumVOD','Episode8'),(81,7,'3QtYoBcJO7g','At0miumVOD','Episode9'),(82,7,'yguaCTHNi3k','At0miumVOD','Episode10'),(83,7,'jT2ZOo5EsQ8','At0miumVOD','Episode11'),(84,7,'HBiNpaocNLA','At0miumVOD','Episode12'),(85,8,'-3o-Q_QoJvk','AlexYuki','Episode1'),(86,8,'Y_APHeS1pmE','AlexYuki','Episode2'),(87,8,'nMvTNzK3jD0','AlexYuki','Episode3'),(88,8,'yHvIXsuhyzQ','AlexYuki','Episode4'),(89,8,'N8V2-5bQmJA','AlexYuki','Episode5'),(90,8,'akImCUC44Mg','AlexYuki','Episode6'),(91,8,'WrbTu5uk1KE','AlexYuki','Episode7'),(92,8,'D-CiBiT5QRc','AlexYuki','Episode8'),(93,8,'Pl9_sfGT1_0','AlexYuki','Episode9'),(94,8,'MiQbkt7Xui8','AlexYuki','Episode10'),(95,8,'HxJKtJKoMLA','AlexYuki','Episode11'),(96,8,'Hb6EFqrHIyM','AlexYuki','Episode12'),(97,9,'xZqnAUKCM80','CohhCarnage','Episode1'),(98,9,'bO9_WEgBCjo','CohhCarnage','Episode2'),(99,9,'iU3NgWrdT1w','CohhCarnage','Episode3'),(100,9,'jPMAI-QHlNk','CohhCarnage','Episode4'),(101,9,'N9U1KrrJ07I','CohhCarnage','Episode5'),(102,9,'7QLRjLf8u14','CohhCarnage','Episode6'),(103,9,'wdT-UoFnCxw','CohhCarnage','Episode7'),(104,9,'DAnVK9fad5U','CohhCarnage','Episode8'),(105,9,'hv6K9bwglqg','CohhCarnage','Episode9'),(106,9,'GEKBGpxiE4o','CohhCarnage','Episode10'),(107,9,'IW247LTTK_E','CohhCarnage','Episode11'),(108,9,'yTpUroHRClE','CohhCarnage','Episode12');
/*!40000 ALTER TABLE `video_youtube` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-23 11:12:25
